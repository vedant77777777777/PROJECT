package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class EditProfilePage  {
    private ImageView companyLogoView;
    private Stage primaryStage;
    static private Scene scene;


    public EditProfilePage(Stage primaryStage){
        this.primaryStage = primaryStage;
        this.scene=initializeEditProfilePage(primaryStage);

    }

    public  Scene initializeEditProfilePage(Stage primaryStage){

        // Load and display background image without blur effect
        Image backgroundImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\beautiful-office-space-cartoon-style.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setFitWidth(1920); // Set width to match your screen size
        backgroundView.setFitHeight(1080); // Set height to match your screen size
        backgroundView.setPreserveRatio(false); // Ensure the image covers the entire area

        // Create UI elements for Edit Profile Page
        Text title = new Text("Edit Profile");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.WHITE);

        // Company logo rounded space
        companyLogoView = new ImageView();
        companyLogoView.setFitHeight(100);
        companyLogoView.setFitWidth(100);
        companyLogoView.setPreserveRatio(true);
        Circle clip = new Circle(50); // Rounded effect
        companyLogoView.setClip(clip);

        // Placeholder for the empty circle
        Circle logoPlaceholder = new Circle(50);
        logoPlaceholder.setStroke(Color.WHITE);
        logoPlaceholder.setFill(null);

        StackPane logoStack = new StackPane(logoPlaceholder, companyLogoView);

        Button uploadLogoButton = new Button("Profile Picture");
        uploadLogoButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        uploadLogoButton.setTextFill(Color.WHITE);
        uploadLogoButton.setStyle("-fx-background-color: #1E90FF; -fx-border-color: transparent; -fx-background-radius: 20px; -fx-padding: 10px 20px;");
        uploadLogoButton.setOnAction(e -> uploadLogo(primaryStage));

        VBox logoBox = new VBox(10, logoStack, uploadLogoButton);
        logoBox.setAlignment(Pos.CENTER);

        // Create text fields for various company details
        TextField companyNameField = createTextField("Company Name");
        TextField locationField = createTextField("Location");
        TextField founderField = createTextField("Founder");
        TextField ceoField = createTextField("CEO Name");
        TextField workforceField = createTextField("Work Force");
        TextField hrManagerField = createTextField("HR Manager Name");
        TextField sinceYearsField = createTextField("Since How Many Years");

        // About message box
        TextArea aboutTextArea = new TextArea();
        aboutTextArea.setPromptText("About Your Company");
        aboutTextArea.setPrefRowCount(5);
        aboutTextArea.setWrapText(true);
        aboutTextArea.setStyle("-fx-background-color: transparent; -fx-border-color: #B0C4DE; -fx-border-width: 2px; -fx-border-radius: 5px; -fx-padding: 5px; -fx-text-fill: black;");

        // Save and Back buttons
        Button saveButton = new Button("Save");
        saveButton.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        saveButton.setTextFill(Color.WHITE);
        saveButton.setStyle("-fx-background-color: #32CD32; -fx-border-color: transparent; -fx-background-radius: 20px; -fx-padding: 10px 20px;");
        saveButton.setOnAction(e -> {
            // Add logic to save profile changes
            System.out.println("Profile saved!");
        });

        Button backButton = new Button("Back");
        backButton.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        backButton.setTextFill(Color.WHITE);
        backButton.setStyle("-fx-background-color: #1E90FF; -fx-border-color: transparent; -fx-background-radius: 20px; -fx-padding: 10px 20px;");
        backButton.setOnAction(e -> {
            // Navigate back to AdminLandingPage
            AdminLandingPage adminPage = new AdminLandingPage(primaryStage);
            primaryStage.setScene(AdminLandingPage.getScene());

            // try {
            //     adminPage.start(primaryStage);
            // } catch (Exception ex) {
            //     ex.printStackTrace();
            // }
        });

        HBox buttonBox = new HBox(20, saveButton, backButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));

        // Layout for the form fields and buttons within the card
        VBox formBox = new VBox(15, title, logoBox, companyNameField, locationField, founderField, ceoField, workforceField, hrManagerField, sinceYearsField, aboutTextArea, buttonBox);
        formBox.setAlignment(Pos.CENTER);
        formBox.setPadding(new Insets(20));
        formBox.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.7), new CornerRadii(20), Insets.EMPTY)));
        formBox.setMaxWidth(600);

        // Content wrapper
        VBox content = new VBox(20, formBox);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(50));

        // StackPane to overlay background and form box
        StackPane stackPane = new StackPane(backgroundView, content);
        stackPane.setAlignment(Pos.CENTER);

        // Wrap the stackPane with ScrollPane
        ScrollPane scrollPane = new ScrollPane(stackPane);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        Scene scene = new Scene(scrollPane, 1920, 1080); // Set scene size as needed
        
        return scene;
        // primaryStage.setScene(scene);
        // primaryStage.setResizable(false); // Prevent resizing
        // primaryStage.show();
    }

    private TextField createTextField(String promptText) {
        TextField textField = new TextField();
        textField.setPromptText(promptText);
        textField.setFont(Font.font("Arial", 16));
        textField.setMaxWidth(300);
        textField.setStyle("-fx-background-color: transparent; -fx-border-color: #B0C4DE; -fx-border-width: 2px; -fx-border-radius: 5px; -fx-padding: 5px; -fx-text-fill: white;");
        textField.setStyle("-fx-prompt-text-fill: #B0C4DE;"); // Set prompt text color to light blue
        return textField;
    }

    private void uploadLogo(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Logo Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", ".png", ".jpg", "*.jpeg")
        );
        File selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            Image logoImage = new Image(selectedFile.toURI().toString(), 100, 100, true, true);
            companyLogoView.setImage(logoImage);
        }
    }

    public static Scene getScene(){
        return scene;
    }


}