package com.example;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class HomePage extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene homeScene = createHomePageScene(primaryStage);
        primaryStage.setScene(homeScene);
        primaryStage.show();
    }

    public Scene createHomePageScene(Stage primaryStage) {
        primaryStage.setTitle("HireBridge");
      //  primaryStage.setHeight(600);
        //primaryStage.setWidth(1000);
        primaryStage.setMaximized(true);
    

       

        // Welcome text
        Text title = new Text("Welcome to HireBridge");
        title.setFont(Font.font("Arial", 30));
        title.setFill(Color.BLACK);

        // Load and resize logo image
        ImageView logoView = null;
        // try {
            // FileInputStream logoInput = new FileInputStream("src/ASSETS/images/logo-no-background.png");
            Image logoImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\logo-no-background.png");
            logoView = new ImageView(logoImage);
            logoView.setFitWidth(150);  // Adjust the width as needed
            logoView.setPreserveRatio(true);
        // } catch (FileNotFoundException ex) {
        //     ex.printStackTrace();
        // }

        // Buttons for login and signup
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-font-size: 15px; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        loginButton.setOnAction(e -> {
            HomeLogin homeLogin = new HomeLogin();
            try {
                homeLogin.start(primaryStage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });

        Button signupButton = new Button("Signup");
        signupButton.setStyle("-fx-font-size: 15px; -fx-background-color: #2196F3; -fx-text-fill: white;");
        signupButton.setOnAction(e -> {
            HomeSignup homeSignup = new HomeSignup();
            try {
                homeSignup.start(primaryStage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });

        HBox buttons = new HBox(20, loginButton, signupButton);
        buttons.setAlignment(Pos.CENTER);

        // Main layout for HomePage
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, javafx.geometry.Insets.EMPTY)));

        // Add logo, welcome text, and buttons to the layout
        if (logoView != null) {
            layout.getChildren().add(logoView);
        }
        layout.getChildren().addAll(title, buttons);

        Scene homeScene = new Scene(layout, 2000, 1200);
        

        // Adding a background image with blur effect
        try {
            FileInputStream bgInput = new FileInputStream("C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\co-workers-working-together.jpg");
            Image backgroundImage = new Image(bgInput);
            ImageView imageView = new ImageView(backgroundImage);
            imageView.setFitWidth(2000);
            imageView.setFitHeight(1200);
            imageView.setEffect(new GaussianBlur(20)); // Adjust the radius for more or less blur

            StackPane stackPane = new StackPane(imageView, layout);
            homeScene.setRoot(stackPane);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        return homeScene;
    }

    // public static void main(String[] args) {
    //     launch(args);
    // }
}