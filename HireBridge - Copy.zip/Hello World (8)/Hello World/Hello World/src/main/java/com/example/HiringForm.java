package com.example;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.firebase_connections.FirebaseServices;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
//import javafx.stage.FileChooser;
//import java.io.File;

public class HiringForm  {

    private Stage primaryStage;
    private static Scene scene;

    public HiringForm(Stage primaryStage){
        
        this.primaryStage = primaryStage;
        this.scene= initializeHiringForm(primaryStage);

    }
    
    public Scene initializeHiringForm(Stage primaryStage) {
        primaryStage.setMaximized(true);

        // Background Image
        Image backgroundImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\jointeam.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setFitWidth(1920);
        backgroundView.setFitHeight(1080);
        backgroundView.setPreserveRatio(true);
        backgroundView.setOpacity(0.7); // Make the image a bit blur by setting opacity

        // Form Title
        Label formTitle = new Label("Hiring Application Form");
        formTitle.setFont(Font.font("Arial", FontWeight.BOLD, 30));
        formTitle.setTextFill(Color.WHITE);

        // Form Fields
        Label nameLabel = new Label("Company Name:");
        nameLabel.setTextFill(Color.WHITE);
        TextField nameField = new TextField();
        nameField.setPromptText("Enter your company name");
        nameField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label emailLabel = new Label("Email:");
        emailLabel.setTextFill(Color.WHITE);
        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");
        emailField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label phoneLabel = new Label("Contact:");
        phoneLabel.setTextFill(Color.WHITE);
        TextField phoneField = new TextField();
        phoneField.setPromptText("Enter your contact");
        phoneField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label addressLabel = new Label("Address:");
        addressLabel.setTextFill(Color.WHITE);
        TextField addressField = new TextField();
        addressField.setPromptText("Enter your address");
        addressField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label websiteLabel = new Label("Website URL:");
        websiteLabel.setTextFill(Color.WHITE);
        TextField websiteField = new TextField();
        websiteField.setPromptText("Enter your website URL");
        websiteField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label salaryLabel = new Label("Salary Range:");
        salaryLabel.setTextFill(Color.WHITE);
        TextField salaryField = new TextField();
        salaryField.setPromptText("Enter the salary range");
        salaryField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label workTimingLabel = new Label("Work Timing:");
        workTimingLabel.setTextFill(Color.WHITE);
        TextField workTimingField = new TextField();
        workTimingField.setPromptText("Enter the work timing");
        workTimingField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label registrationLinkLabel = new Label("Registration Link:");
        registrationLinkLabel.setTextFill(Color.WHITE);
        TextField registrationLinkField = new TextField();
        registrationLinkField.setPromptText("Enter the registration link");
        registrationLinkField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label positionLabel = new Label("Position Applied For:");
        positionLabel.setTextFill(Color.WHITE);
        TextField positionField = new TextField();
        positionField.setPromptText("Enter the position");
        positionField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");

        Label resumeLabel = new Label("Upload Jop Discription:");
        resumeLabel.setTextFill(Color.WHITE);
        Button uploadButton = new Button("Upload");
        uploadButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;");
        uploadButton.setOnMouseEntered(e -> uploadButton.setStyle("-fx-background-color: #45A049; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        uploadButton.setOnMouseExited(e -> uploadButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
       
        // Upload Button Action
          uploadButton.setOnAction(e -> {
           FileChooser fileChooser = new FileChooser();
          fileChooser.setTitle("Choose File");
    // Set extension filters if needed
    File selectedFile = fileChooser.showOpenDialog(primaryStage);
    if (selectedFile != null) {
        // Handle the selected file (e.g., display its path)
        System.out.println("Selected file: " + selectedFile.getAbsolutePath());
        // You can further process the file as needed
    }
});


        // Submit Button
        Button submitButton = new Button("Submit");
        submitButton.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        submitButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;");
        submitButton.setOnMouseEntered(e -> submitButton.setStyle("-fx-background-color: #222222; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        submitButton.setOnMouseExited(e -> submitButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        submitButton.setOnAction(e -> {
            // Handle form submission
            System.out.println("Form submitted!");
        });

        // Back Button
        Button backButton = new Button("Back");
        backButton.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;");
        backButton.setOnMouseEntered(e -> backButton.setStyle("-fx-background-color: #222222; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        backButton.setOnMouseExited(e -> backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        backButton.setOnAction(e -> {
            // Navigate back to AdminLandingPage
            AdminLandingPage adminLandingPage = new AdminLandingPage(primaryStage);
            primaryStage.setScene(AdminLandingPage.getScene());
        });

        // Layout
        GridPane formGrid = new GridPane();
        formGrid.setAlignment(Pos.TOP_CENTER);
        formGrid.setPadding(new Insets(20));
        formGrid.setHgap(10);
        formGrid.setVgap(10);

        formGrid.add(formTitle, 0, 0, 2, 1);
        formGrid.add(nameLabel, 0, 1);
        formGrid.add(nameField, 1, 1);
        formGrid.add(emailLabel, 0, 2);
        formGrid.add(emailField, 1, 2);
        formGrid.add(phoneLabel, 0, 3);
        formGrid.add(phoneField, 1, 3);
        formGrid.add(addressLabel, 0, 4);
        formGrid.add(addressField, 1, 4);
        formGrid.add(websiteLabel, 0, 5);
        formGrid.add(websiteField, 1, 5);
        formGrid.add(salaryLabel, 0, 6);
        formGrid.add(salaryField, 1, 6);
        formGrid.add(workTimingLabel, 0, 7);
        formGrid.add(workTimingField, 1, 7);
        formGrid.add(registrationLinkLabel, 0, 8);
        formGrid.add(registrationLinkField, 1, 8);
        formGrid.add(positionLabel, 0, 9);
        formGrid.add(positionField, 1, 9);
        formGrid.add(resumeLabel, 0, 10);
        formGrid.add(uploadButton, 1, 10);

        HBox buttonBox = new HBox(10, backButton, submitButton);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        formGrid.add(buttonBox, 1, 11);

        formGrid.setStyle("-fx-background-color: rgba(0, 0, 0, 0.6); -fx-background-radius: 20px; -fx-padding: 20px;");
        formGrid.setMaxWidth(800);

    //     VBox vBox = new VBox(formGrid);
    //     vBox.setAlignment(Pos.TOP_CENTER);
    //     vBox.setPadding(new Insets(50, 0, 0, 0));
    //     //VBox dataVbox = new VBox();
    //    // dataVbox.getChildren().add(loadProjectDetails());
    //     // dataVbox.setAlignment(Pos.CENTER_LEFT);
    //     StackPane stackPane = new StackPane(backgroundView, leftSection,vBox);
    //     StackPane.setAlignment(vBox, Pos.TOP_CENTER);

        // Notification Button
        Button notificationButton = new Button("Notifications");
        notificationButton.setFont(Font.font("Arial", FontWeight.BOLD, 220));
        notificationButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;");
        // notificationButton.setOnMouseEntered(e -> notificationButton.setStyle("-fx-background-color: #222222; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        // notificationButton.setOnMouseExited(e -> notificationButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        // // Add notification button to handle notifications

        // Avatar Image
        Image avatarImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\noti.jpg");
        ImageView avatarImageView = new ImageView(avatarImage);
        avatarImageView.setFitWidth(100);
        avatarImageView.setFitHeight(100);
        

        // Left Section with Avatar and Notification Button
        VBox leftSection = new VBox(20, avatarImageView,notificationButton);
        leftSection.setAlignment(Pos.TOP_CENTER);
         
        leftSection.getChildren().add(loadProjectDetails());
        leftSection.setPadding(new Insets(150));
        leftSection.setStyle("-fx-background-color: rgba(0, 0, 0, 0.6); -fx-background-radius: 20px;");

        VBox vBox = new VBox(formGrid);
        vBox.setAlignment(Pos.TOP_CENTER);
        vBox.setPadding(new Insets(50, 0, 0, 0));
        //VBox dataVbox = new VBox();
       // dataVbox.getChildren().add(loadProjectDetails());
        // dataVbox.setAlignment(Pos.CENTER_LEFT);
        StackPane stackPane = new StackPane(backgroundView, leftSection,vBox);
        StackPane.setAlignment(vBox, Pos.TOP_CENTER);
        

        // ScrollPane
        HBox mainLayout = new HBox(leftSection, stackPane);
        mainLayout.setAlignment(Pos.CENTER_LEFT);

        // ScrollPane
        ScrollPane scrollPane = new ScrollPane(mainLayout);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        Scene hiringScene = new Scene(scrollPane, 1920, 1080);
        primaryStage.setScene(hiringScene);
        primaryStage.setResizable(true);
        primaryStage.show();
        return hiringScene;
    }
    
    private VBox loadProjectDetails() {
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        try {
            vbox.getChildren().clear(); // Clear existing cards
            List<Map<String, Object>> filledForms = 
                FirebaseServices.getDataInDescendingOrder("Applicant", "timestamp");
            
            for (Map<String, Object> form : filledForms) {
                HBox formCard = createProjectCard(form);
                vbox.getChildren().add(formCard);
            }
        } catch (ExecutionException | InterruptedException ex) {
            ex.printStackTrace();
        }
        return vbox;
    }
    private HBox createProjectCard(Map<String, Object> form) {
        HBox card = new HBox();
        card.setPadding(new Insets(10));
        card.setSpacing(10);
        card.setStyle("-fx-border-color: black; -fx-border-width: 1; -fx-background-color: #f0f0f0;");
    
        VBox projectVBox = new VBox();
        projectVBox.setSpacing(5);
    
    

        // Assuming projectDetail contains keys like "title" and "description"
        Label applicantName = new Label("Applicant Name: "+(String) form.get("applicantName"));
        applicantName.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
    
        Label applicantRole = new Label("Role:" +(String) form.get("applicantRole"));
        applicantRole.setWrapText(true);
    
        Label addressField = new Label("Address:"+(String) form.get("addressField"));
        addressField.setWrapText(true);
    
        
    
        Label applicantAge = new Label("Age:"+(String) form.get("applicantAge"));
        applicantAge.setWrapText(true);
    
        Label cityField = new Label("City:"+(String) form.get("cityField"));
        cityField.setWrapText(true);
    
        Label educationField = new Label("Education field:"+(String) form.get("educationField"));
        educationField.setWrapText(true);
    
        Label country = new Label("Country:"+(String) form.get("country"));
        country.setWrapText(true);

        Label phoneField = new Label("Contact:"+(String) form.get("phoneField"));
        phoneField.setWrapText(true);

        Label stateField = new Label("State:"+(String) form.get("stateField"));
        stateField.setWrapText(true);

        Image image = new Image((String)form.get("applicantImg"));
        ImageView imageView = new ImageView(image);
    
        projectVBox.getChildren().addAll(applicantName,phoneField,applicantAge,applicantRole,addressField,cityField,stateField,country,educationField);
    
        card.getChildren().add(projectVBox);
    
        return card;
    }
    private void handleFormSubmission(Stage primaryStage) {
        // Logic to handle form submission
        // For demonstration purposes, showing a dialog box
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Form Submitted");
        alert.setHeaderText(null);
        alert.setContentText("Your hiring application form has been submitted successfully!");
        alert.showAndWait();
    }

   

    public static Scene getHiringForm(){
        return scene;
    }
}
