package com;

public class ApplicantInfo {
    

    private String userName;    // Username of the user
    private String password;    // Password of the user
    private String role;        // Role or type of user (e.g., admin, regular user)

    // Getters and setters for each field
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Override toString() to provide a string representation of the object
    @Override
    public String toString() {
        return "UserDetail [userName=" + userName + ", password=" + password + ", role=" + role + "]";
    }
}
