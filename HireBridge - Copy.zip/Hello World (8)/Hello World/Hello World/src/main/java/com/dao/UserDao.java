package com.dao;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.ApplicantInfo;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;

/**
 * Data Access Object (DAO) class for UserDetail entities.
 */
public class UserDao {
    public static Firestore db; // Firestore instance to interact with the database

    /**
     * Method to add data to a specific document in a collection.
     * @param collection The name of the collection.
     * @param document The name of the document.
     * @param data The data to add as a map of key-value pairs.
     * @throws ExecutionException If there is an issue executing the write operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public void addData(String collection, String document, Map<String, Object> data) throws ExecutionException, InterruptedException {
        DocumentReference docRef = db.collection(collection).document(document); // Reference to the document
        ApiFuture<WriteResult> result = docRef.set(data); // Set data in the document
        result.get(); // Block until the operation is complete
    }

    /**
     * Method to retrieve a single UserDetail object from a document in a collection.
     * @param collection The name of the collection.
     * @param document The name of the document.
     * @return The UserDetail object.
     * @throws ExecutionException If there is an issue executing the read operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public ApplicantInfo getData(String collection, String document) throws ExecutionException, InterruptedException {
        try {
            DocumentReference docRef = db.collection(collection).document(document); // Reference to the document
            ApiFuture<DocumentSnapshot> future = docRef.get(); // Asynchronously retrieve document snapshot
            return future.get().toObject(ApplicantInfo.class); // Convert document snapshot to UserDetail object
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
            throw e; // Re-throw the exception or handle it based on your application's needs
        }
    }
}
