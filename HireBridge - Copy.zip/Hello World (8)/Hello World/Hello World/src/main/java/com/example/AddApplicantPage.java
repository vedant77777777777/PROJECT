package com.example;

import java.io.File;
import com.controller.ApplicantController;

import com.controller.ImageUploader;
import com.model.Applicant;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AddApplicantPage {
    private HomeLogin ApplicantAdd = new HomeLogin();
    private static String country = null, imgUrl = null;
    private Stage primaryStage;

    /**
     * Constructor to initialize the AddPlayerPage with a specific country.
     * 
     * @param country The country for which the player is being added.
     */
    public AddApplicantPage(String country) {
        AddApplicantPage.country = country;
    }

    /**
     * Setter for the primary stage.
     * 
     * @param primaryStage The primary stage to set.
     */
    void setAddPlayerPage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    /**
     * Method to create the player addition scene.
     * 
     * @param backHandler Runnable handler for the back button action.
     * @return The VBox containing the player addition UI components.
     */
    public VBox createApplicantScene(Runnable backHandler) {
        // Back button setup
        Button backButton = new Button("Back");
        backButton.setStyle(
                "-fx-pref-width: 120;-fx-min-height: 30;-fx-background-radius: 15;-fx-background-color : #2196F3; -fx-text-fill:#FFFFFF");

        backButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent c2w_pi_event) {
                backHandler.run(); // Execute the back handler
            }
        });

        // Title label setup
        Label title = new Label("Add Applicant");
        title.setStyle(
                "-fx-font-size:30 ;-fx-font-weight: bold; -fx-pref-width: 500; -fx-pref-height: 30; -fx-alignment : LEFT; -fx-text-fill:#FFFFFF");

        // Button box containing the back button
        HBox buttonBox = new HBox(100, backButton);
        buttonBox.setStyle("-fx-pref-size : 1000 400; -fx-padding : 30 ; ");
        buttonBox.setAlignment(Pos.TOP_LEFT);

        // Form for player details
        VBox form = createApplicantForm();
        form.getChildren().add(0, title); // Add title to the top of the form
        form.setStyle(
                "-fx-pref-height : 480 ; -fx-max-width : 440; -fx-alignment : TOP_CENTER ; -fx-padding : 20 20 20 40 ;-fx-background-color : rgba(0, 0, 0, 0.5);");

        // VBox to hold all components of the player addition page
        VBox ApplicantVBox = new VBox(10, buttonBox, form);
        ApplicantVBox.setAlignment(Pos.TOP_CENTER);
        ApplicantVBox.setStyle(
                "-fx-background-image: url('images/cricketGround2.jpg'); -fx-background-size: cover; -fx-padding : 0 0 50 0");

        return ApplicantVBox;
    }

    /**
     * Creates the form for entering player details.
     * 
     * @return The VBox containing the player detail form components.
     */
    private VBox createApplicantForm() {
        // Default player image setup
        Image ApplicantImg = new Image("images/dummy.png");
        ImageView ApplicantImgView = new ImageView(ApplicantImg);
        ApplicantImgView.setFitHeight(120);
        ApplicantImgView.setStyle("-fx-border-color: black; -fx-border-width: 1px;-fx-border-style: solid;");
        ApplicantImgView.setPreserveRatio(true);
        HBox ApplicantImage_hb = new HBox(ApplicantImgView);
        ApplicantImage_hb.setStyle("-fx-pref-size : 350 20;-fx-alignment : CENTER");

        // Player name input setup
        Label ApplicantNameLabel = new Label("Enter Applicant Name : ");
        ApplicantNameLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold; -fx-text-fill:#FFFFFF");
        TextField ApplicantNametf = new TextField();
        ApplicantNametf.setPromptText("Enter Applicant Name");
        ApplicantNametf.setStyle("-fx-pref-width : 180; -fx-text-fill:#FFFFFF");
        HBox ApplicantName = new HBox(10, ApplicantNameLabel, ApplicantNametf);
        ApplicantName.setMaxSize(400, 20);

        // Player age input setup
        Label ApplicantAgeLabel = new Label("Enter Applicant Age : ");
        ApplicantAgeLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold; -fx-text-fill:#FFFFFF");
        TextField ApplicantAgetf = new TextField();
        ApplicantAgetf.setPromptText("Enter Applicant Age");
        ApplicantAgetf.setStyle("-fx-pref-width : 180; -fx-text-fill:#FFFFFF");
        HBox ApplicantAge = new HBox(10, ApplicantAgeLabel, ApplicantAgetf);
        ApplicantAge.setMaxSize(400, 20);

        // Player country input setup
        Label ApplicantCountryLabel = new Label("Enter Applicant Country : ");
        ApplicantCountryLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold; -fx-text-fill:#FFFFFF");
        TextField ApplicantCountrytf = new TextField();
        if (country != null)
            ApplicantCountrytf.setText(country);
        ApplicantCountrytf.setPromptText("Enter Player Country");
        ApplicantCountrytf.setStyle("-fx-pref-width : 180; -fx-text-fill:#FFFFFF");
        HBox ApplicantCountry = new HBox(10, ApplicantCountryLabel, ApplicantCountrytf);
        ApplicantCountry.setMaxSize(400, 20);

        // Player role input setup
        Label ApplicantRoleLabel = new Label("Enter Applicant Role : ");
        ApplicantRoleLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold; -fx-text-fill:#FFFFFF");
        TextField ApplicantRoletf = new TextField();
        ApplicantRoletf.setPromptText("Enter Applicant Role");
        ApplicantRoletf.setStyle("-fx-pref-width : 180; -fx-text-fill:#FFFFFF");
        HBox ApplicantRole = new HBox(10, ApplicantRoleLabel, ApplicantRoletf);
        ApplicantRole.setMaxSize(400, 20);

        // Player batting style input setup
        // Label c2w_pi_playerBatStyleLabel = new Label("Enter Player Batting Style :
        // ");
        // c2w_pi_playerBatStyleLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold;
        // -fx-text-fill:#FFFFFF");
        // TextField c2w_pi_playerBatStyletf = new TextField();
        // c2w_pi_playerBatStyletf.setPromptText("Enter Player Batting Style");
        // c2w_pi_playerBatStyletf.setStyle("-fx-pref-width : 180;
        // -fx-text-fill:#FFFFFF");
        // HBox c2w_pi_playerBatStyle = new HBox(10, c2w_pi_playerBatStyleLabel,
        // c2w_pi_playerBatStyletf);
        // c2w_pi_playerBatStyle.setMaxSize(400, 20);

        // Player bowling style input setup
        // Label c2w_pi_playerBowlStyleLabel = new Label("Enter Player Bowling Style :
        // ");
        // c2w_pi_playerBowlStyleLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold;
        // -fx-text-fill:#FFFFFF");
        // TextField c2w_pi_playerBowlStyletf = new TextField();
        // c2w_pi_playerBowlStyletf.setPromptText("Enter Player Bowling Style");
        // c2w_pi_playerBowlStyletf.setStyle("-fx-pref-width : 180;
        // -fx-text-fill:#FFFFFF");
        // HBox c2w_pi_playerBowlStyle = new HBox(10,c2w_pi_playerBowlStyleLabel,
        // c2w_pi_playerBowlStyletf);
        // c2w_pi_playerBowlStyle.setMaxSize(400, 20);
        // // Country flag input setup

        // Label c2w_pi_countryFlagLabel = new Label("Enter Country Flag : ");
        // c2w_pi_countryFlagLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold;
        // -fx-text-fill:#FFFFFF");

        // TextField c2w_pi_countryFlagtf = new TextField();
        // c2w_pi_countryFlagtf.setPromptText("Enter Country Flag");
        // c2w_pi_countryFlagtf.setStyle("-fx-pref-width : 180;-fx-text-fill:#FFFFFF");

        // HBox c2w_pi_countryFlagImg = new HBox(10,c2w_pi_countryFlagLabel,
        // c2w_pi_countryFlagtf);
        // c2w_pi_countryFlagImg.setMaxSize(400, 20);
        // Player info URL input setup
        Label ApplicantInfoUrlLabel = new Label("Enter Info URL Resume : ");
        ApplicantInfoUrlLabel.setStyle("-fx-font-size:12;-fx-font-weight:bold; -fx-text-fill:#FFFFFF");

        TextField ApplicantInfoUrltf = new TextField();
        ApplicantInfoUrltf.setPromptText("Enter Info URL Resume");
        ApplicantInfoUrltf.setStyle("-fx-pref-width : 180;-fx-text-fill:#FFFFFF");

        HBox ApplicantInfoUrl = new HBox(10, ApplicantInfoUrlLabel, ApplicantInfoUrltf);
        ApplicantInfoUrl.setMaxSize(400, 20);
        // Button to add player data
        Button addButton = new Button("Add Data");
        addButton.setStyle(
                "-fx-pref-width:120;-fx-min-height: 30;-fx-background-radius: 15;-fx-background-color : #2196F3; -fx-text-fill:#FFFFFF");
        HBox buttonBox = new HBox(addButton);
        buttonBox.setAlignment(Pos.CENTER);
        // Output label for messages
        Label output = new Label();

        output.setStyle("fx-font-size:12;-fx-text-fill:#FFFFFF");

        // File chooser setup for player image selection
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")

        );
        // Event handler for clicking on the player image view to select an image

        ApplicantImgView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent c2w_pi_event) {
                File selectedFile = fileChooser.showOpenDialog(primaryStage);
                if (selectedFile != null) {
                    String imageUrl = ImageUploader.uploadImage(selectedFile.getPath(),
                            selectedFile.getName());

                    imgUrl = imageUrl;
                    if (imageUrl != null) {
                        Image image = new

                        Image(imageUrl);
                        ApplicantImgView.setImage(image);

                    }
                }
            }
        });
        // Event handler for adding player data
        addButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override

            public void handle(ActionEvent event) {
                // Create a Player object and set its attributes from the input fields

                Applicant Applicant = new Applicant();
                Applicant.setApplicantName(ApplicantNametf.getText());
                Applicant.setApplicantAge(ApplicantAgetf.getText());
                Applicant.setCountry(ApplicantCountrytf.getText());
                //Applicant.setApplicantRole(ApplicantRoletf.getText());
                // Applicant.setBattingStyle(c2w_pi_playerBatStyletf.getText());
                // Applicant.setBowlingStyle(c2w_pi_playerBowlStyletf.getText());
                Applicant.setInfoUrl(ApplicantInfoUrltf.getText());
                // Applicant.setFlag(c2w_pi_countryFlagtf.getText());

                if (imgUrl != null)
                    Applicant.setApplicantImg(imgUrl);
                else
                    output.setText("Applicant add Image");
                // Check if all compulsory fields are filled
                // if (checkCompulsoryFields(Applicant)) {
                //     // Attempt to add the player using the PlayerController
                //     if (ApplicantAdd.addApplicants(Applicant)) {
                //         output.setText("Applicant Added Successfully");

                //     } else {
                //         output.setText("Applicant Not Added");

                //     }
                // } else {
                //     output.setText("Fields are Empty");
                // }
            }
        });
        // VBox to contain all form components and output label
        VBox page = new VBox(20,  ApplicantImage_hb,
                ApplicantName, ApplicantAge, ApplicantCountry,
                ApplicantRole, ApplicantInfoUrl,buttonBox,
                output);

        return page;
    }

    /**
     * Method to check if all compulsory fields in the player
     * object are filled.
     * 
     * @param Applicant The player object to check.
     * @return True if all compulsory fields are filled, false
     *         otherwise.
     */
    
}