package com.example;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.effect.BoxBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.firebase_connections.FirebaseServices;


public class SplashScreen extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        FirebaseServices.initializeFirebase();
        primaryStage.setTitle("Splash Screen");
        


        // Background image
        ImageView backgroundImageView = null;
        try {
            Image backgroundImage = new Image(new FileInputStream("C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\businesswomen-using-sign-language-work-talk-each-other.jpg"));
            backgroundImageView = new ImageView(backgroundImage);
            backgroundImageView.setFitWidth(primaryStage.getWidth());
            backgroundImageView.setFitHeight(primaryStage.getHeight());
            backgroundImageView.setEffect(new BoxBlur(10, 10, 3)); // Adding blur effect
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        // Logo image
        ImageView logoImageView = null;
        try {
            Image logoImage = new Image(new FileInputStream("C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\logo-no-background.png"));
            logoImageView = new ImageView(logoImage);
            logoImageView.setFitWidth(400);
            logoImageView.setFitHeight(400);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        // Loading text
        Text loadingText = new Text("Loading...");
        loadingText.setFont(Font.font("Arial", 24));
        loadingText.setFill(Color.BLACK);

        // StackPane to hold the background image, logo, and loading text
        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY))); // Dark background
        if (backgroundImageView != null && logoImageView != null) {
            root.getChildren().addAll(backgroundImageView, logoImageView);
        }
        
        // Positioning loading text at the bottom right corner
        StackPane.setAlignment(loadingText, Pos.BOTTOM_RIGHT);
        StackPane.setMargin(loadingText, new Insets(0, 20, 20, 0)); // Adjust margins

        root.getChildren().add(loadingText);

        Scene scene = new Scene(root);

        primaryStage.setScene(scene);
        primaryStage.show();

        // Transition to HOME page after 2 seconds (adjust as needed)
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> {
            HomePage homePage = new HomePage();


            try {
                homePage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }));
        timeline.play();
    }

    // public static void main(String[] args) {
    //     launch(args);
    // }
}
