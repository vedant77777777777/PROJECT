package com.dao;

public interface UserDetail {

}
