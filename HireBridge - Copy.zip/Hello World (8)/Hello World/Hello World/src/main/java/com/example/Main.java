package com.example;

import java.io.IOException;

import com.firebase_connections.FirebaseServices;
import com.google.firebase.internal.FirebaseService;

import javafx.application.Application;

public class Main {

    public static void main(String[] args) {
       
            Application.launch(SplashScreen.class, args);
         //   Application.launch(AdminLandingPage.class, args);
    
       
    }
}
