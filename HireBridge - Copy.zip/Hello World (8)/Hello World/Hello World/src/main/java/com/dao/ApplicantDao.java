package com.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;
import com.model.Applicant;

public class ApplicantDao {
    
    public static Firestore db; // Firestore instance to interact with the database

    /**
     * Constructor for ApplicantDao.
     * (Currently empty, but can be used for initialization if needed)
     */
    public ApplicantDao() {
        // Constructor (if needed for any initialization)
    }

    /**
     * Method to add data to a specific document in a collection.
     * @param collection The name of the collection.
     * @param document The name of the document.
     * @param data The Applicant object to add.
     * @throws ExecutionException If there is an issue executing the write operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public void addData(String collection, String document, Applicant data) throws ExecutionException, InterruptedException {
        DocumentReference docRef = db.collection(collection).document(document); // Reference to the document
        ApiFuture<WriteResult> result = docRef.set(data); // Set data in the document
        result.get(); // Block until operation is complete
    }

    /**
     * Method to retrieve a single Applicant object from a document in a collection.
     * @param collection The name of the collection.
     * @param document The name of the document.
     * @return The Applicant object.
     * @throws ExecutionException If there is an issue executing the read operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public Applicant getData(String collection, String document) throws ExecutionException, InterruptedException {
        try {
            DocumentReference docRef = db.collection(collection).document(document); // Reference to the document
            ApiFuture<DocumentSnapshot> future = docRef.get(); // Asynchronously retrieve document snapshot
            return future.get().toObject(Applicant.class); // Convert document snapshot to Applicant object
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
            throw e; // Re-throw exception or handle based on application's needs
        }
    }

    /**
     * Method to retrieve a list of Applicant objects from a collection.
     * @param collection The name of the collection.
     * @return A list of Applicant objects.
     * @throws ExecutionException If there is an issue executing the read operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public List<Applicant> getDataList(String collection) throws ExecutionException, InterruptedException {
        try {
            CollectionReference colRef = db.collection(collection); // Reference to the collection
            ApiFuture<QuerySnapshot> future = colRef.get(); // Asynchronously retrieve all documents in collection
            QuerySnapshot querySnapshot = future.get(); // Get query snapshot containing all documents
            List<QueryDocumentSnapshot> c2w_pi_documents = querySnapshot.getDocuments(); // Extract list of document snapshots

            List<Applicant> dataList = new ArrayList<>();
            for (QueryDocumentSnapshot document : c2w_pi_documents) {
                Applicant object = document.toObject(Applicant.class); // Convert each document snapshot to Applicant object
                dataList.add(object); // Add Applicant object to list
            }
            return dataList; // Return list of Applicant objects
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
            throw e; // Re-throw exception or handle based on application's needs
        }
    }

    /**
     * Method to retrieve a filtered list of Applicant objects based on country.
     * @param collection The name of the collection.
     * @param country The country to filter by.
     * @return A filtered list of Applicant objects.
     * @throws ExecutionException If there is an issue executing the read operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public List<Applicant> getDataList(String collection, String country) throws ExecutionException, InterruptedException {
        try {
            CollectionReference colRef = db.collection(collection); // Reference to the collection
            Query query = colRef.whereEqualTo("country", country); // Query to filter documents by country
            ApiFuture<QuerySnapshot> future = query.get(); // Asynchronously retrieve filtered query snapshot
            QuerySnapshot querySnapshot = future.get(); // Get query snapshot containing filtered documents
            List<QueryDocumentSnapshot> c2w_pi_documents = querySnapshot.getDocuments(); // Extract list of document snapshots

            List<Applicant> dataList = new ArrayList<>();
            for (QueryDocumentSnapshot document : c2w_pi_documents) {
                Applicant object = document.toObject(Applicant.class); // Convert each document snapshot to Applicant object
                dataList.add(object); // Add Applicant object to list
            }
            return dataList; // Return filtered list of Applicant objects
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
            throw e; // Re-throw exception or handle based on application's needs
        }
    }

    /**
     * Method to search for Applicant objects based on a key (ApplicantName or country).
     * @param key The key to search by (ApplicantName or country).
     * @return A list of Applicant objects matching the search key.
     * @throws ExecutionException If there is an issue executing the read operation.
     * @throws InterruptedException If the thread is interrupted while waiting for the operation to complete.
     */
    public List<Applicant> getSearchApplicant(String key) throws ExecutionException, InterruptedException {
        CollectionReference Applicants = db.collection("Applicant"); // Reference to the "Applicant" collection
        Query nameQuery = Applicants.whereEqualTo("ApplicantName", key); // Query to filter by ApplicantName
        Query countryQuery = Applicants.whereEqualTo("country", key); // Query to filter by country

        ApiFuture<QuerySnapshot> nameQuerySnapshot = nameQuery.get(); // Asynchronously retrieve query snapshot for ApplicantName
        ApiFuture<QuerySnapshot> countryQuerySnapshot = countryQuery.get(); // Asynchronously retrieve query snapshot for country

        List<QueryDocumentSnapshot> nameDocuments = nameQuerySnapshot.get().getDocuments(); // Get documents matching ApplicantName query
        List<QueryDocumentSnapshot> countryDocuments = countryQuerySnapshot.get().getDocuments(); // Get documents matching country query

        Set<DocumentSnapshot> uniqueDocuments = new HashSet<>();
        uniqueDocuments.addAll(nameDocuments); // Add documents from ApplicantName query to set
        uniqueDocuments.addAll(countryDocuments); // Add documents from country query to set

        List<Applicant> userList = new ArrayList<>();
        for (DocumentSnapshot document : uniqueDocuments) {
            if (document.exists()) {
                Applicant user = document.toObject(Applicant.class); // Convert document snapshot to Applicant object
                userList.add(user); // Add Applicant object to list
            }
        }
        return userList; // Return list of Applicant objects matching search key
    }
}


