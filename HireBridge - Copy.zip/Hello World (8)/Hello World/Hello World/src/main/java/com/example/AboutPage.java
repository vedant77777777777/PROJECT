package com.example;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AboutPage {

    private Stage primaryStage;
    private static Scene scene;

    public AboutPage(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.scene = initAboutScene();
    }

    public Scene getScene() {
        return scene;
    }

    private Scene initAboutScene() {
        // Background Image
        Image backgroundImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\golden-frame-blue-background.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setFitWidth(1920);
        backgroundView.setFitHeight(1080);
        backgroundView.setPreserveRatio(true);

        // Title
        Text title = new Text("About Us");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 40));
        title.setFill(Color.WHITE);

        // About Text
        Text aboutText = new Text(
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla posuere molestie felis, ut eleifend urna pellentesque vel. Sed consequat augue id diam malesuada, vitae facilisis lorem elementum. Sed varius, orci nec semper vestibulum, leo mi feugiat lorem, at tristique neque dui et metus. Nulla facilisi."
        );
        aboutText.setFont(Font.font("Arial", 20));
        aboutText.setFill(Color.WHITE);
        aboutText.setWrappingWidth(800); // Set preferred width for wrapping

        // Back Button
        Button backButton = new Button("Back");
        backButton.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        backButton.setTextFill(Color.WHITE);
        backButton.setStyle("-fx-background-color: #1e88e5; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 20px; -fx-background-radius: 20px;");
        backButton.setOnAction(e -> {
            // Navigate back to AdminLandingPage
            AdminLandingPage adminLandingPage = new AdminLandingPage(primaryStage);
            primaryStage.setScene(adminLandingPage.getScene());
        });

        // Center Layout
        VBox centerBox = new VBox(20, title, aboutText, backButton);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setPadding(new Insets(50));
        centerBox.setBackground(new javafx.scene.layout.Background(new javafx.scene.layout.BackgroundFill(Color.rgb(0, 0, 0, 0.7), new CornerRadii(10), javafx.geometry.Insets.EMPTY)));

        // BorderPane layout to organize header and footer
        BorderPane layout = new BorderPane();
        layout.setCenter(centerBox);

        // StackPane to stack background and main layout
        StackPane stackPane = new StackPane(backgroundView, layout);

        // Setting up the Scene
        Scene aboutScene = new Scene(stackPane, 1920, 1080);
        return aboutScene;
    }
}