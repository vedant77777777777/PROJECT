package com.example;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.controller.UserController;


import com.controller.BackgroundImageController;
//import com.controller.UserController;

/**
 * This class represents the signup page of the application.
 */
public class HomeSignup {
    private UserController userController = new UserController(); // Controller for user-related operations
    private BackgroundImageController backgroundImg = new BackgroundImageController(); // Controller for background image


    public void start(Stage primaryStage) {
        
        primaryStage.setTitle("Signup Page");
        throw new UnsupportedOperationException("Unimplemented method 'start'");
    // }
    }
    /**
     * Creates and returns the signup scene.
     * 
     * @param backHandler A Runnable to handle the action of going back to the previous scene.
     * @return The signup scene.
     */
    public Scene createSignupScene(Runnable backHandler) {
        // Logo image
        ImageView logo = new ImageView("images/c2w.png");
        logo.setFitWidth(40);
        logo.setPreserveRatio(true);

        // Title label
        Label title = new Label("Welcome to Players Info");
        title.setStyle("-fx-font-size:25; -fx-font-weight: bold; -fx-pref-width: 600; -fx-pref-height: 30; -fx-alignment: CENTER; -fx-text-fill:#FFFFFF");

        // Header VBox containing logo and title
        VBox header = new VBox(10, logo, title);
        header.setAlignment(Pos.CENTER);

        // Label and TextField for username
        Label userLabel = new Label("Username:");
        TextField userTextField = new TextField();
        userTextField.setPromptText("Enter Username");
        userTextField.setFocusTraversable(false);
        userTextField.setStyle("-fx-max-width: 270; -fx-min-height: 30; -fx-background-radius: 15;");

        // Label and PasswordField for password
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        passField.setFocusTraversable(false);
        passField.setPromptText("Enter Password");
        passField.setStyle("-fx-min-width: 270; -fx-min-height: 30; -fx-background-radius: 15;");

        // Button to trigger signup action
        Button signupButton = new Button("Signup");
        signupButton.setStyle("-fx-pref-width: 70; -fx-min-height: 30; -fx-background-radius: 15; -fx-background-color: #2196F3; -fx-text-fill: #FFFFFF");

        // Label to navigate to login scene
        Label loginButton = new Label("Login");
        loginButton.setStyle("-fx-background-radius: 15; -fx-text-fill: white");

        // TextField to show password in plain text
        TextField textFieldPassword = new TextField();
        textFieldPassword.setPromptText("Enter Password");
        textFieldPassword.setFocusTraversable(false);
        textFieldPassword.setVisible(false);
        textFieldPassword.setStyle("-fx-min-width: 270; -fx-min-height: 30; -fx-background-radius: 15;");
        textFieldPassword.textProperty().bindBidirectional(passField.textProperty());

        // Images for toggle icon
        Image hide = new Image("images/hide.png");
        Image show = new Image("images/show.png");
        ImageView icon = new ImageView(show);
        icon.setFitWidth(30);
        icon.setPreserveRatio(true);

        // HBox for password fields
        HBox passBox = new HBox(10, passField);
        passBox.setPrefWidth(400);

        // HBox for toggle icon
        HBox iconBox = new HBox(10, icon);
        iconBox.setMaxWidth(70);
        iconBox.setAlignment(Pos.BASELINE_LEFT);

        // StackPane for password field and icon
        StackPane passFieldStackPane = new StackPane(passBox, iconBox);
        passFieldStackPane.setAlignment(Pos.BASELINE_RIGHT);

        // Label for output messages
        Label output = new Label();
        output.setStyle("-fx-text-fill: white;");

        // Style the labels
        userLabel.setStyle("-fx-text-fill: white;");
        passLabel.setStyle("-fx-text-fill: white;");

        // VBox layouts for the fields and buttons
        VBox fieldBox1 = new VBox(10, userLabel, userTextField);
        fieldBox1.setMaxSize(300, 30);
        VBox fieldBox2 = new VBox(10, passLabel, passFieldStackPane);
        fieldBox2.setMaxSize(300, 30);

        // Set action for the signup button
        signupButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!userTextField.getText().isEmpty() && !passField.getText().isEmpty()) {
                    if (userController.handleSignup(userTextField.getText(), passField.getText())) {
                        HomeLogin loginPage = new HomeLogin();
                        loginPage.getLoginScene();
                    } else {
                        output.setText("User not Registered");
                    }
                } else {
                    output.setText("Please Enter Username and Password");
                }
            }
        });

        // Set action for the login button
        loginButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                backHandler.run();
            }
        });

        // Toggle visibility of password
        icon.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent c2w_pi_event) {
                if (passField.isVisible()) {
                    passField.setVisible(false);
                    textFieldPassword.setVisible(true);
                    passBox.getChildren().remove(0);
                    passBox.getChildren().add(0, textFieldPassword);
                    icon.setImage(hide);
                } else {
                    passField.setVisible(true);
                    textFieldPassword.setVisible(false);
                    passBox.getChildren().remove(0);
                    passBox.getChildren().add(0, passField);
                    icon.setImage(show);
                }
            }
        });

        // Main VBox layout for the signup page
        VBox loginBox = new VBox(20, header, fieldBox1, fieldBox2, signupButton, loginButton, output);
        loginBox.setStyle("-fx-pref-height: 200; -fx-alignment: TOP_CENTER; -fx-padding: 30; -fx-background-color: rgba(0, 0, 0, 0.5);");
        loginBox.setAlignment(Pos.CENTER);
        loginBox.setMaxSize(400, 200);
        loginBox.setOpacity(0.8);

        // StackPane for the signup page
        StackPane sp = new StackPane(loginBox);
        sp.setStyle("-fx-background-image:url('" +backgroundImg.imageData() + "');-fx-background-size: cover;");

        // Return the signup scene
        return new Scene(sp, 1000, 800);
    }

    // public void start(Stage primaryStage) {
    //     // TODO Auto-generated method stub
    //     throw new UnsupportedOperationException("Unimplemented method 'start'");
    // }
}
