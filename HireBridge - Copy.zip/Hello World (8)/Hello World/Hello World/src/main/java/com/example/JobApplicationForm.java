package com.example;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

import org.threeten.bp.LocalDate;

import com.controller.ApplicantController;
import com.controller.ImageUploader;
import com.model.Applicant;

public class JobApplicationForm {
    private static String imgUrl = null;

    static ApplicantController controller = new ApplicantController();

    public static Scene createScene(Stage primaryStage) {

        // Form elements
        Label titleLabel = new Label("Job Application Form");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label output = new Label();
        Label nameLabel = new Label("Name:");
        TextField applicantNameTf = new TextField();
        applicantNameTf.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        applicantNameTf.setPromptText("Enter your name");

        Label emailLabel = new Label("Email:");
        TextField applicantAgeTf = new TextField();
        applicantAgeTf.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        applicantAgeTf.setPromptText("Enter your email");

        Label phoneLabel = new Label("Phone:");
        TextField phoneField = new TextField();
        phoneField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        phoneField.setPromptText("Enter your phone number");

        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();
        addressField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        addressField.setPromptText("Enter your address");

        Label cityLabel = new Label("City:");
        TextField cityField = new TextField();
        cityField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        cityField.setPromptText("Enter your city");

        Label stateLabel = new Label("State:");
        TextField stateField = new TextField();
        stateField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        stateField.setPromptText("Enter your state");

        Label countryLabel = new Label("Country:");
        TextField applicantCountryTf = new TextField();
        applicantCountryTf.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        applicantCountryTf.setPromptText("Enter your country");

        Label educationLabel = new Label("Education:");
        TextField educationField = new TextField();
        educationField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); -fx-text-fill: black; -fx-padding: 10px; -fx-background-radius: 10px;");
        educationField.setPromptText("Enter your education background");

        Label resumeLabel = new Label("Upload Resume:");
        Button uploadButton = new Button("Choose File");
        uploadButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10px 20px; -fx-background-radius: 5px;");
        Label fileLabel = new Label("No file chosen");
        FileChooser fileChooser = new FileChooser();
        uploadButton.setOnAction(e -> {
            File selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                imgUrl = ImageUploader.uploadImage(selectedFile.getPath(), selectedFile.getName());
                fileLabel.setText(selectedFile.getName());
            }
        });

        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10px 20px; -fx-background-radius: 5px;");
        submitButton.setOnAction(e -> {
            // Create a confirmation dialog
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to submit this form?");

            // Customize buttons in the dialog
            ButtonType submitButtonType = new ButtonType("Submit");
            ButtonType cancelButtonType = new ButtonType("Cancel");
            alert.getButtonTypes().setAll(submitButtonType, cancelButtonType);

            // Show and wait for user interaction
            alert.showAndWait().ifPresent(buttonType -> {
                if (buttonType == submitButtonType) {
                    // User clicked "Submit", proceed with submission logic
                    System.out.println("Form submitted!");
                    Applicant applicant = new Applicant();
                    applicant.setApplicantName(applicantNameTf.getText());
                    applicant.setApplicantAge(applicantAgeTf.getText());
                    applicant.setCountry(applicantCountryTf.getText());
                    applicant.setPhoneField(phoneField.getText());
                    applicant.setAddressField(addressField.getText());
                    applicant.setCityField(cityField.getText());
                    applicant.setStateField(stateField.getText());
                    applicant.setEducationField(educationField.getText());
                    applicant.setTimestamp(LocalDate.now().toString());

                    if (imgUrl != null)
                        applicant.setApplicantImg(imgUrl);
                    else
                        output.setText("Please upload an image");

                    // Check if all compulsory fields are filled
                    if (checkCompulsoryFields(applicant)) {
                        // Attempt to add the applicant using the controller
                        if (controller.addApplicants(applicant)) {
                            output.setText("Applicant Added Successfully");
                        } else {
                            output.setText("Applicant Not Added");
                        }
                    } else {
                        output.setText("Fields are Empty");
                    }
                } else {
                    // User clicked "Cancel" or closed the dialog
                    System.out.println("Submission canceled.");
                }
            });
        });

        // Back Button
        Button backButton = new Button("Back");
        backButton.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;");
        backButton.setOnMouseEntered(e -> backButton.setStyle("-fx-background-color: #222222; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        backButton.setOnMouseExited(e -> backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-background-radius: 10px;"));
        backButton.setOnAction(e -> {
            // Navigate back to UserloginLandingPage
            UserloginLandingPage userLandingPage = new UserloginLandingPage(primaryStage);
            primaryStage.setScene(userLandingPage.getScene());
        });

        // Layout
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(titleLabel, 0, 0, 2, 1); // span title across two columns
        GridPane.setHalignment(titleLabel, HPos.CENTER);

        gridPane.add(nameLabel, 0, 1);
        gridPane.add(applicantNameTf, 1, 1);
        gridPane.add(emailLabel, 0, 2);
        gridPane.add(applicantAgeTf, 1, 2);
        gridPane.add(phoneLabel, 0, 3);
        gridPane.add(phoneField, 1, 3);
        gridPane.add(addressLabel, 0, 4);
        gridPane.add(addressField, 1, 4);
        gridPane.add(cityLabel, 0, 5);
        gridPane.add(cityField, 1, 5);
        gridPane.add(stateLabel, 0, 6);
        gridPane.add(stateField, 1, 6);
        gridPane.add(countryLabel, 0, 7);
        gridPane.add(applicantCountryTf, 1, 7);
        gridPane.add(educationLabel, 0, 8);
        gridPane.add(educationField, 1, 8);
        gridPane.add(resumeLabel, 0, 9);
        HBox uploadBox = new HBox(10, uploadButton, fileLabel);
        gridPane.add(uploadBox, 1, 9);

        HBox buttonBox = new HBox(10, backButton, submitButton);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        gridPane.add(buttonBox, 0, 10, 2, 1); // span across two columns

        // Styling for the gridPane
        gridPane.setStyle("-fx-background-color: rgba(192, 192, 192, 0.8); -fx-padding: 20px; -fx-background-radius: 10px;");

        // Set preferred size for text fields
        applicantNameTf.setPrefWidth(300);
        applicantAgeTf.setPrefWidth(300);
        phoneField.setPrefWidth(300);
        addressField.setPrefWidth(300);
        cityField.setPrefWidth(300);
        stateField.setPrefWidth(300);
        applicantCountryTf.setPrefWidth(300);
        educationField.setPrefWidth(300);

        // Set gridPane constraints
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setHalignment(HPos.RIGHT);
        gridPane.getColumnConstraints().add(column1);

        // Set VBox size
        gridPane.setMinSize(800, 800);
        gridPane.setMaxSize(800, 800);

        VBox vbox = new VBox(gridPane);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));

        // Add background image
        BackgroundImage backgroundImage = new BackgroundImage(
                new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\abc.jpg", 1820, 800, false, true),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT
        );
        vbox.setBackground(new Background(backgroundImage));

        Scene scene = new Scene(vbox, 1920, 1080);

        // Add inline CSS styling
        scene.getRoot().setStyle(
                "-fx-font-family: 'Arial';" +
                        "-fx-label-font-size: 16px;" +
                        "-fx-label-text-fill: black;" +
                        "-fx-text-field-background-color: rgba(255, 255, 255, 1);" +
                        "-fx-text-field-text-fill: black;" +
                        "-fx-text-field-font-size: 14px;" +
                        "-fx-text-field-padding: 10px;" +
                        "-fx-text-field-border-radius: 5px;" +
                        "-fx-text-field-border-color: #ccc;" +
                        "-fx-text-field-border-width: 1px;" +
                        "-fx-button-background-color: #000000;" +
                        "-fx-button-text-fill: white;" +
                        "-fx-button-font-size: 16px;" +
                        "-fx-button-padding: 10px 20px;" +
                        "-fx-button-border-radius: 5px;" +
                        "-fx-button-hover-background-color: #333333;" +
                        "-fx-hbox-spacing: 10px;" +
                        "-fx-hbox-alignment: center;" +
                        "-fx-vbox-spacing: 20px;" +
                        "-fx-vbox-alignment: center;" +
                        "-fx-vbox-padding: 20px;"
        );

        return scene;
    }

    private static boolean checkCompulsoryFields(Applicant applicant) {
        return !applicant.getApplicantName().trim().isEmpty() &&
                !applicant.getApplicantAge().trim().isEmpty() &&
                !applicant.getApplicantImg().trim().isEmpty() &&
                !applicant.getCountry().trim().isEmpty() &&
                !applicant.getStateField().trim().isEmpty() &&
                !applicant.getAddressField().trim().isEmpty() &&
                !applicant.getEducationField().trim().isEmpty() &&
                !applicant.getPhoneField().trim().isEmpty();
    }
}
