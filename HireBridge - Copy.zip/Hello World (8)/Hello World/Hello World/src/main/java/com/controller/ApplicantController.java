package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.dao.ApplicantDao;

import com.model.Applicant;

/**
 * Controller class to manage player-related operations.
 * 
 * 
 */

 public class ApplicantController {

    private com.dao.ApplicantDao ApplicantDao = new ApplicantDao(); // Instance of PlayerDao to interact with the database

    /**
     * Method to retrieve all players from the database.
     * 
     * @return A list of all Player objects.
     */
    public List<Applicant> getAllApplicants() {
        try {
            return ApplicantDao.getDataList("Applicant"); // Retrieve all players from the "player" collection
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace(); // Print stack trace for debugging
        }
        return new ArrayList<>(); // Return an empty list if an exception occurs
    }

    /**
     * Method to add a player to the database.
     * 
     * @param data The Player object to be added.
     * @return true if the player is added successfully, false otherwise.
     */
    public boolean addApplicants(Applicant data) {
        try {
            ApplicantDao.addData("Applicant", data.getApplicantName(), data); // Add player to the "player" collection
            System.out.println("Data Added");
            return true; // Return true if the player is added successfully
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace(); // Print stack trace for debugging
        }
        return false; // Return false if an exception occurs
    }

    /**
     * Method to search for players based on a key (playerName or country).
     * 
     * @param key The search key.
     * @return A list of Player objects that match the search key.
     */
    public List<Applicant> getSearchApplicant(String key) {
        try {
            return ApplicantDao.getSearchApplicant(key); // Search for players based on the key
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace(); // Print stack trace for debugging
        }
        return new ArrayList<>(); // Return an empty list if an exception occurs
    }

    /**
     * Method to retrieve all unique countries and their flags from the player
     * database.
     * 
     * @return A map where the key is the country name and the value is the flag URL.
     */
    public Map<String, String> getAllCountries() {
        Map<String, String> countries = new HashMap<>();

        // Map to store country names and flag URLs

        List<Applicant> ApplicantList = getAllApplicants(); // Retrieve all players

        for (Applicant Applicant : ApplicantList) {
            if (!countries.containsKey(Applicant.getCountry())) { // If the country is not already in the map
                countries.put(Applicant.getCountry(), Applicant.getFlag()); // Add country and flag to the map
            }
        }
        return countries; // Return the map of countries and flags
    }

    /**
     * Method to retrieve all players from a specific country.
     * 
     * @param country The name of the country.
     * @return A list of Player objects from the specified country.
     */
    public List<Applicant> getAllApplicantsByCountry(String country) {
        try {
            return ApplicantDao.getDataList("Applicant", country); // Retrieve players from the specified country
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace(); // Print stack trace for debugging
        }
        return new ArrayList<>(); // Return an empty list if an exception occurs
    }
}
