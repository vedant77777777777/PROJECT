package com.example;



import java.util.List;
import com.controller.ApplicantController;
import com.model.Applicant;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 * This class represents the UI for displaying a list of players.
 */
public class ApplicantListPage {
    private Stage primaryStage;
    private ApplicantController ApplicantController = new ApplicantController(); // Service to interact with Firestore
    private Scene ApplicantListScene, AddApplicantScene;
    static String country = null;
    VBox vb; // VBox to hold the user scene components

    /**
     * Constructor to initialize the country for which player list is displayed.
     * @param country The country name.
     */
    public ApplicantListPage(String country) {
        ApplicantListPage.country = country;
    }

    /**
     * Setter for the player list scene.
     * @param scene The scene to set.
     */
    public void setPlayerListScene(Scene scene){
        this.ApplicantListScene = scene;
    }

    /**
     * Setter for the primary stage.
     * @param primaryStage The primary stage to set.
     */
    public void setPlayerListPage(Stage primaryStage){
        this.primaryStage = primaryStage;
    }

    /**
     * Constructor to initialize the PlayerListPage with a specific PlayerController instance.
     * @param ApplicantController The PlayerController instance to use.
     */
    public ApplicantListPage(ApplicantController ApplicantController) {
        this.ApplicantController = ApplicantController;
    }

    /**
     * Method to create the player list scene.
     * @param backHandler The handler for the back button.
     * @return The VBox containing the player list scene components.
     */
    public VBox createPlayerListScene(Runnable backHandler) {
        // Create UI components
        Button logoutButton = new Button("Back"); // Button to trigger logout action
        logoutButton.setStyle("-fx-pref-width: 120;-fx-min-height: 30;-fx-background-radius: 15;-fx-background-color: #2196F3; -fx-text-fill:#FFFFFF");

        Label title = new Label("Applicant List of " + country); // Label to display the country name
        title.setStyle("-fx-font-size:30 ;-fx-font-weight: bold; -fx-pref-width: 700; -fx-pref-height: 30; -fx-alignment: CENTER");

        Button AddApplicant = new Button("Add Applicant");
        AddApplicant.setStyle("-fx-pref-width: 120;-fx-min-height: 30;-fx-background-radius: 15;-fx-background-color: #2196F3; -fx-text-fill:#FFFFFF");

        HBox header = new HBox(50, logoutButton, title, AddApplicant);
        header.setStyle("-fx-pref-width: 800; -fx-pref-height: 30;");

        VBox cardList = new VBox(10);
        List<Applicant> ApplicantList = ApplicantController.getAllApplicantsByCountry(country);

        // Create player cards for each player in the list
        for (Applicant applicant : ApplicantList) {
            cardList.getChildren().add(createApplicantCard(applicant));
        }

        // Set action for the back button
        logoutButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                backHandler.run(); // Run the back handler
            }
        });

        // Set action for the add player button
        AddApplicant.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                initAddApplicantScene(); // Initialize add player scene
                primaryStage.setScene(AddApplicantScene); // Show add player scene
                primaryStage.setTitle("Admin Dashboard");
            }
        });

        // Scroll pane to hold the list of player cards
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(cardList);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: #D3D3D3;");

        // Create a VBox layout for the player list scene components
        vb = new VBox(30, header, scrollPane);
        vb.setStyle("-fx-background-color:#D3D3D3; -fx-padding: 30;"); // Set background color and padding

        return vb; // Return the created VBox
    }

    /**
     * Initializes the add player scene.
     */
    private void initAddApplicantScene() {
        AddApplicantPage AddApplicantPage = new AddApplicantPage(country); // Create AddPlayerPage instance
        AddApplicantPage.setAddPlayerPage(primaryStage);

        AddApplicantScene = new Scene(AddApplicantPage.createApplicantScene(this::handleBack), 1000, 800); // Create add player scene
    }

    /**
     * Handler for navigating back from add player scene to player list scene.
     */
    private void handleBack() {
        primaryStage.setScene(ApplicantListScene); // Show player list scene
    }

    /**
     * Creates a player card UI component.
     * @param Applicant The player object to display.
     * @return The HBox containing the player card.
     */
    HBox createApplicantCard(Applicant Applicant) {
        // Create and style player image
        Image ApplicantImage = new Image(Applicant.getApplicantImg());
        ImageView ApImageView = new ImageView(ApplicantImage);
        ApImageView.setFitHeight(120);
        ApImageView.setPreserveRatio(true);
        ApImageView.setStyle("-fx-border-color: black; -fx-border-width: 1px;-fx-border-style: solid;");

        Circle clip = new Circle(60, 60, 60); // CenterX, CenterY, Radius
        ApImageView.setClip(clip);

        // Create player name label
        Label ApplicantName = new Label(Applicant.getApplicantName());
        ApplicantName.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        HBox name = new HBox(ApplicantName);

        // Create age label
        Label ageLabel = new Label("Age: ");
        ageLabel.setStyle("-fx-font-weight: bold;");
        Label ApplicantAge = new Label(String.valueOf(Applicant.getApplicantAge()));
        HBox age = new HBox(ageLabel, ApplicantAge);

        // // Create role label
        // Label roleLabel = new Label("Role: ");
        // roleLabel.setStyle("-fx-font-weight: bold;");
        // Label ApplicantRole = new Label(Applicant.getApplicantRole());
        // HBox role = new HBox(roleLabel, ApplicantRole);

        // // Create batting style label
        // Label c2w_pi_batStyleLabel = new Label("Batting Style: ");
        // c2w_pi_batStyleLabel.setStyle("-fx-font-weight: bold;");
        // Label c2w_pi_battingStyle = new Label(Applicant.getBattingStyle());
        // HBox c2w_pi_batStyle = new HBox(c2w_pi_batStyleLabel, c2w_pi_battingStyle);

        // // Create bowling style label
        // Label c2w_pi_bowlStyleLabel = new Label("Bowling Style: ");
        // c2w_pi_bowlStyleLabel.setStyle("-fx-font-weight: bold;");
        // Label c2w_pi_bowlingStyle = new Label(Applicant.getBowlingStyle());
        // HBox c2w_pi_bowlStyle = new HBox(c2w_pi_bowlStyleLabel, c2w_pi_bowlingStyle);

        // VBox to hold player information
        VBox ApplicantInfo = new VBox(3, name, age);
        // HBox to hold entire player card
        HBox card = new HBox(20,ApImageView,ApplicantInfo);
        
        card.setStyle("-fx-border-color: black;-fx-border-width: 2px;-fx-border-style: solid; -fx-border-radius:5px; -fx-background: WHITE;");
        return card;
    }
}

 
    

