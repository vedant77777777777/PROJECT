package com.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.Acl;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

/**
 * Class for uploading images to Google Cloud Storage.
 */
public class ImageUploader {

    private static final String BUCKET_NAME = "javafx-dce2b.appspot.com"; // Replace with your Google Cloud Storage bucket name

    /**
     * Uploads an image file to Google Cloud Storage and returns the publicly accessible URL.
     * 
     * @param localFilePath  The local file path of the image to upload.
     * @param uploadFileName The name of the file to be uploaded.
     * @return The publicly accessible URL of the uploaded image.
     */
    public static String uploadImage(String localFilePath, String uploadFileName) {

        try {
            // Read service account credentials from a JSON file
            FileInputStream serviceAccount = new FileInputStream("C:\\Users\\DELL\\Desktop\\CORE\\Maven Projects\\c2w\\src\\main\\resources\\javafx-dce2b-firebase-adminsdk-tuhdy-7e81325d6b.json");

            // Authenticate and create a storage instance
            Storage storage = StorageOptions.newBuilder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build()
                    .getService();

            // Read bytes from the local file
            Path path = Paths.get(localFilePath);
            byte[] bytes = Files.readAllBytes(path);

            // Define Blob ID and BlobInfo
            BlobId blobId = BlobId.of(BUCKET_NAME, uploadFileName);

            BlobInfo blobInfo = BlobInfo.newBuilder(blobId)
                    .setContentType("image/jpeg") // Set content type
                    .setAcl(Arrays.asList(Acl.of(Acl.User.ofAllUsers(), Acl.Role.READER))) // Make file publicly accessible
                    .build();

            // Upload the image bytes to Google Cloud Storage
            storage.create(blobInfo, bytes);

            // Return the URL of the uploaded image
            return "https://storage.googleapis.com/" + BUCKET_NAME + "/" + uploadFileName;

        } catch (IOException e) {
            e.printStackTrace();
            return null; // Return null if there's an exception
        }
    }
}
