package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.BoxBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.concurrent.ExecutionException;

import com.firebase_connections.FirebaseServices;
import com.model.Applicant;

public class HomeLogin extends Application {

    private Stage primaryStage;
    private FirebaseServices firebaseService;
    private Scene scene;
    private boolean isAdminSelected = false; // Flag to track selected role

    public void setPrimaryStageScene(Scene scene) {

        primaryStage.setScene(scene);
    }

    public void initializeLoginScene() {
        Scene loginScene = createLoginScene();
        this.scene = loginScene;
        primaryStage.setScene(loginScene);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Login Page");
        primaryStage.setMaximized(true);
        

        Scene scene = createLoginScene();
        this.scene = scene;
        primaryStage.setTitle("Firebase Auth Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Scene createLoginScene() {
        // Background image
        ImageView backgroundImageView = null;
        try {
            Image backgroundImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\AdobeStock_375393450_Preview.jpeg");
            backgroundImageView = new ImageView(backgroundImage);
            backgroundImageView.setFitWidth(1920);
            backgroundImageView.setFitHeight(1080);
            backgroundImageView.setEffect(new BoxBlur(10, 10, 3)); // Adjusted blur effect
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // Title text
        Text title = new Text("𝙻𝚘𝚐𝚒𝚗 ");
        title.setFont(Font.font("Bodoni MT Black", FontWeight.BOLD, 50)); // Increased font size
        title.setFill(Color.BLANCHEDALMOND); // Text color (white)
        title.setStroke(Color.BLACK); // Border color
        title.setStrokeWidth(2); // Border width
        title.setTextAlignment(TextAlignment.CENTER);

        // Background for the title text
        Rectangle titleBackground = new Rectangle(title.getLayoutBounds().getWidth() + 20, title.getLayoutBounds().getHeight() + 10);
        titleBackground.setFill(Color.TRANSPARENT); // Light transparent background
        titleBackground.setStroke(Color.TRANSPARENT); // Border color
        titleBackground.setStrokeWidth(2); // Border width

        StackPane titlePane = new StackPane(titleBackground, title);
        titlePane.setAlignment(Pos.CENTER);

        // Admin and User buttons with enhanced styling
        Button adminButton = new Button("Admin");
        adminButton.setStyle("-fx-font-size: 20px; -fx-background-radius: 15; -fx-background-color: black; -fx-text-fill: white;"); // Black background and rounded corners

        Button userButton = new Button("User");
        userButton.setStyle("-fx-font-size: 20px; -fx-background-radius: 15; -fx-background-color: black; -fx-text-fill: white;"); // Black background and rounded corners

        // Hover effects for buttons
        adminButton.setOnMouseEntered(e -> adminButton.setStyle("-fx-font-size: 20px; -fx-background-radius: 15; -fx-background-color: darkgrey; -fx-text-fill: white;"));
        adminButton.setOnMouseExited(e -> adminButton.setStyle("-fx-font-size: 20px; -fx-background-radius: 15; -fx-background-color: black; -fx-text-fill: white;"));

        userButton.setOnMouseEntered(e -> userButton.setStyle("-fx-font-size: 20px; -fx-background-radius: 15; -fx-background-color: darkgrey; -fx-text-fill: white;"));
        userButton.setOnMouseExited(e -> userButton.setStyle("-fx-font-size: 20px; -fx-background-radius: 15; -fx-background-color: black; -fx-text-fill: white;"));

        // Vertical line between buttons
        Line verticalLine = new Line(0, 0, 0, 30);
        verticalLine.setStroke(Color.WHITE);
        verticalLine.setStrokeWidth(2);

        // HBox for buttons and line with reduced spacing
        HBox buttonBox = new HBox(adminButton, verticalLine, userButton);
        buttonBox.setSpacing(5); // Adjusted spacing
        buttonBox.setAlignment(Pos.CENTER);

        // Username and Password fields
        TextField emailField = new TextField();
        emailField.setPromptText("Enter username");
        emailField.setMaxWidth(400); // Adjusted width
        emailField.setAlignment(Pos.CENTER);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");
        passwordField.setMaxWidth(400); // Adjusted width
        passwordField.setAlignment(Pos.CENTER);

        firebaseService = new FirebaseServices(emailField, passwordField);

        // Card-like background for username and password with blur effect
        Rectangle cardBg = new Rectangle(800, 400); // Adjusted width and height
        cardBg.setArcWidth(30);
        cardBg.setArcHeight(30);
        cardBg.setFill(Color.rgb(0, 0, 0, 0.5)); // Transparent black
        cardBg.setEffect(new BoxBlur(10, 10, 3));
        cardBg.setStroke(Color.LIGHTGRAY);
        cardBg.setStrokeWidth(2);

        // VBox for fields and buttonBox
        VBox fieldsBox = new VBox(20, buttonBox, emailField, passwordField); // Adjusted spacing
        fieldsBox.setAlignment(Pos.CENTER);
        StackPane fieldsPane = new StackPane(cardBg, fieldsBox);
        fieldsPane.setAlignment(Pos.CENTER);

        // Back button (Navigate back to Home page)
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 20px; -fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 10 20;"); // Adjusted font size and padding
        backButton.setOnAction(e -> {
            // HomePage homePage = new HomePage();
            // try {
            //     homePage.start(primaryStage);
            // } catch (Exception e1) {
            //     e1.printStackTrace();
            // }
        });

        // Login button (Navigate to the appropriate landing page based on the selected role)
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-font-size: 20px; -fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10 20;"); // Adjusted font size and padding
        loginButton.setDisable(true); // Initially disabled

        // Set action for Login button (enabled only when Admin or User is selected)
        loginButton.setOnAction(e -> {
            System.out.println(isAdminSelected);
            if (isAdminSelected) {
                try {
                    System.out.println(emailField.getText());
                        System.out.println(passwordField.getText());
                    if(FirebaseServices.isAdmin(emailField.getText())&&FirebaseServices.authenticateAdmin(emailField.getText(),passwordField.getText())){
                        
                        AdminLandingPage adminLandingPage = new AdminLandingPage(primaryStage);
                        
                        // UserloginLandingPage userloginLandingPage = new UserloginLandingPage(primaryStage);
                        
                        primaryStage.setScene(AdminLandingPage.getScene());
                        primaryStage.show();
                    }
                } catch (Exception e1) {
                    
                    e1.printStackTrace();
                } 
                // try {
                //     adminLandingPage.start(primaryStage);
                // } catch (Exception e1) {
                //     e1.printStackTrace();
                // }
            } else {
                // UserloginLandingPage userLandingPage = new UserloginLandingPage(primaryStage);
                try {
                    System.out.println("Ram Ram");
                    if(FirebaseServices.authenticateUser(emailField.getText(),passwordField.getText())){
                        UserloginLandingPage userloginLandingPage = new UserloginLandingPage(primaryStage);
                        primaryStage.setScene(userloginLandingPage.getScene());
                    }
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } 
                // try {
                //     userLandingPage.start(primaryStage);
                // } catch (Exception e1) {
                //     e1.printStackTrace();
                // }
            }
        });
         

        // Set action for Admin button
         
        //     System.out.println(emailField.getText());
        //     System.out.println(passwordField.getText());
        //     if (FirebaseServices.authenticateAdmin(emailField.getText(), passwordField.getText())) {
        //         new UserloginLandingPage().start(primaryStage); 
        //          //Application.launch(UserloginLandingPage.class,null);
        //      }
        //  } catch (ExecutionException | InterruptedException e1) {
             
        //      e1.printStackTrace();
        //  })
        adminButton.setOnAction(e -> {
            isAdminSelected = true;
            emailField.setPromptText("Enter Admin username");
            passwordField.setPromptText("Enter Admin password");
            loginButton.setDisable(false); // Enable login button
        });

        // Set action for User button
        userButton.setOnAction(e -> {
            isAdminSelected = false;
            emailField.setPromptText("Enter User username");
            passwordField.setPromptText("Enter User password");
            loginButton.setDisable(false); // Enable login button
        });

        // Layout for buttons
        HBox buttonLayout = new HBox(40, backButton, loginButton); // Adjusted spacing
        buttonLayout.setAlignment(Pos.CENTER);

        // Main layout for Login page
        VBox layout = new VBox(40); // Adjusted spacing
        layout.setPadding(new Insets(40)); // Adjusted padding
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(titlePane, fieldsPane, buttonLayout);

        // StackPane to hold the background image and the layout
        StackPane root = new StackPane();
        if (backgroundImageView != null) {
            root.getChildren().add(backgroundImageView);
        }
        root.getChildren().add(layout);

        return new Scene(root, 1920, 1080);
    }

    public boolean addApplicants(Applicant applicant) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addApplicants'");
    }

    public void getLoginScene() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getLoginScene'");
    }
}
