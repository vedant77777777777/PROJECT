package com.model;

public class Applicant {
     // Fields representing player attributes
     private String ApplicantName;     // Name of the player
     private String ApplicantImg;      // URL or path to the player's image
     private String ApplicantAge;      // Age of the player
     private String ApplicantRole;     // Role or position of the player
     //private String battingStyle;   // Batting style of the player
     //private String bowlingStyle;   // Bowling style of the player
     private String country;        // Country the player represents or belongs to
     private String infoUrl;        // URL for additional information about the player
     private String flag;           // URL or path to the flag representing the player's country
    private String phoneField;
    private String addressField;
    private String cityField;
    private String stateField;
    private String educationField;
    private String timestamp;

    public String getApplicantName() {
        return ApplicantName;
    }
    public void setApplicantName(String applicantName) {
        ApplicantName = applicantName;
    }
    public String getApplicantImg() {
        return ApplicantImg;
    }
    public void setApplicantImg(String applicantImg) {
        ApplicantImg = applicantImg;
    }
    public String getApplicantAge() {
        return ApplicantAge;
    }
    public void setApplicantAge(String applicantAge) {
        ApplicantAge = applicantAge;
    }
    public String getApplicantRole() {
        return ApplicantRole;
    }
    public void setApplicantRole(String applicantRole) {
        ApplicantRole = applicantRole;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getInfoUrl() {
        return infoUrl;
    }
    public void setInfoUrl(String infoUrl) {
        this.infoUrl = infoUrl;
    }
    public String getFlag() {
        return flag;
    }
    public void setFlag(String flag) {
        this.flag = flag;
    }
    public String getPhoneField() {
        return phoneField;
    }
    public void setPhoneField(String phoneField) {
        this.phoneField = phoneField;
    }
    public String getAddressField() {
        return addressField;
    }
    public void setAddressField(String addressField) {
        this.addressField = addressField;
    }
    public String getCityField() {
        return cityField;
    }
    public void setCityField(String cityField) {
        this.cityField = cityField;
    }
    public String getStateField() {
        return stateField;
    }
    public void setStateField(String stateField) {
        this.stateField = stateField;
    }
    public String getEducationField() {
        return educationField;
    }
    public void setEducationField(String educationField) {
        this.educationField = educationField;
    }
    @Override
    public String toString() {
        return "Applicant [ApplicantName=" + ApplicantName + ", ApplicantImg=" + ApplicantImg + ", ApplicantAge="
                + ApplicantAge + ", ApplicantRole=" + ApplicantRole + ", country=" + country + ", infoUrl=" + infoUrl
                + ", flag=" + flag + ", phoneField=" + phoneField + ", addressField=" + addressField + ", cityField="
                + cityField + ", stateField=" + stateField + ", educationField=" + educationField + "]";
    }
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp=timestamp;
    }

 
 }
 
    

