package com.firebase_connections;

import com.dao.ApplicantDao;
import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;
import com.google.firebase.cloud.FirestoreClient;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import okhttp3.*;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class FirebaseServices {

    private static final String FIREBASE_AUTH_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=YOUR_FIREBASE_API_KEY";

    // private FirebaseAuth auth;
    // private DatabaseReference database;
    private TextField emailField;
    private PasswordField passwordField;

    public FirebaseServices(TextField emailField, PasswordField passwordField) {
        this.emailField = emailField;
        this.passwordField = passwordField;
    }

    public static Firestore db;

    public static void initializeFirebase() {
        try {
            FileInputStream serviceAccount = new FileInputStream(
                    "Hello World\\Hello World\\src\\main\\resources\\javafx-dce2b-firebase-adminsdk-tuhdy-d671631fc0.json");
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();
            FirebaseApp.initializeApp(options);
            db = FirestoreClient.getFirestore();
            ApplicantDao.db = db;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static DocumentSnapshot getData(String collection, String document)
            throws ExecutionException, InterruptedException {
        try {
            DocumentReference docRef = db.collection(collection).document(document);
            ApiFuture<DocumentSnapshot> future = docRef.get();
            return future.get();
        } catch (Exception e) {
            e.printStackTrace(); // Example: Print the stack trace for debugging
            throw e; // Re-throw the exception
        }

    }

    // static{
    // try {
    // initializeFirebase();
    // System.out.println(123);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }

    // public void loginUser(String email, String password, boolean isAdmin) {
    // OkHttpClient client = new OkHttpClient();

    // JSONObject jsonRequest = new JSONObject();
    // try {
    // jsonRequest.put("email", email);
    // jsonRequest.put("password", password);
    // jsonRequest.put("returnSecureToken", true);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }

    // RequestBody body = RequestBody.create(jsonRequest.toString(),
    // MediaType.parse("application/json; charset=utf-8"));
    // Request request = new Request.Builder()
    // .url(FIREBASE_AUTH_URL)
    // .post(body)
    // .build();

    // client.newCall(request).enqueue(new Callback() {
    // @Override
    // public void onFailure(Call call, IOException e) {
    // showAlert("Login failed. Please try again.");
    // e.printStackTrace();
    // }

    // @Override
    // public void onResponse(Call call, Response response) throws IOException {
    // if (!response.isSuccessful()) {
    // showAlert("Invalid credentials. Please try again.");
    // } else {
    // try {
    // JSONObject jsonResponse = new JSONObject(response.body().string());
    // String idToken = jsonResponse.getString("idToken");
    // verifyIdToken(idToken, isAdmin);
    // } catch (Exception e) {
    // showAlert("Login failed. Please try again.");
    // e.printStackTrace();
    // }
    // }
    // }
    // });
    // }

    // private void verifyIdToken(String idToken, boolean isAdmin) {
    // try {
    // FirebaseToken decodedToken = auth.verifyIdToken(idToken);
    // String uid = decodedToken.getUid();
    // checkUserRole(uid, isAdmin);
    // } catch (FirebaseAuthException e) {
    // showAlert("Invalid token. Please try again.");
    // e.printStackTrace();
    // }
    // }
    public boolean isUser(String username) throws ExecutionException, InterruptedException {
        System.out.println(db);
        DocumentSnapshot dSnapshot = db.collection("user").document(username).get().get();
        if (dSnapshot.exists()) {
            String role = dSnapshot.getString("role");
            return "user".equals(role);
        }
        return false;

    }

    public static boolean authenticateUser(String username, String password)
            throws ExecutionException, InterruptedException {
        System.out.println(username);
        System.out.println("IN USER AUTHENTICATE METHOD");

        DocumentSnapshot dSnapshot = db.collection("user").document(username).get().get();
        System.out.println(dSnapshot);
        if (dSnapshot.exists()) {
            String storedPass = dSnapshot.getString("password");
            System.out.println(password);
            System.out.println(username);
            return password.equals(storedPass);
        }
        return false;
    }

    // private void checkUserRole(String uid, boolean isAdmin) {
    // DatabaseReference userRef = database.child("users").child(uid);
    // userRef.addListenerForSingleValueEvent(new ValueEventListener() {
    // @Override
    // public void onDataChange(DataSnapshot snapshot) {
    // if (snapshot.exists()) {
    // Boolean role = snapshot.child("role").getValue(Boolean.class);
    // if (role != null && role == isAdmin) {
    // // Proceed to the respective landing page
    // if (isAdmin) {
    // // Navigate to Admin landing page
    // // Implement navigation logic here
    // } else {
    // // Navigate to User landing page
    // // Implement navigation logic here
    // }
    // } else {
    // showAlert("Incorrect role. Please try again.");
    // }
    // } else {
    // showAlert("User role not found. Please try again.");
    // }
    // }

    // @Override
    // public void onCancelled(DatabaseError error) {
    // showAlert("Failed to retrieve user role. Please try again.");
    // }
    // });
    // }
    public static boolean isAdmin(String username) throws ExecutionException, InterruptedException {
        System.out.println(username);
        DocumentSnapshot dSnapshot = db.collection("admin").document(username).get().get();
        if (dSnapshot.exists()) {
            String role = dSnapshot.getString("role");
            System.out.println(role);
            return "ADMIN".equals(role);
        }
        return false;

    }

    public static boolean authenticateAdmin(String userName, String password)
            throws ExecutionException, InterruptedException {
        System.out.println(db);
        System.out.println("IN ADMIN AUTHENTICATE METHOD");
        DocumentSnapshot dSnapshot = db.collection("admin").document(userName).get().get();
        System.out.println(dSnapshot);
        if (dSnapshot.exists()) {
            String storedPass = dSnapshot.getString("password");
            return password.equals(storedPass);
        }
        return false;
        // }
        // public static boolean authenticateAdmin(String username,String
        // password)throws ExecutionException,InterruptedException{
        // System.out.println(db);
        // DocumentSnapshot dSnapshot =
        // db.collection("user").document(username).get().get();
        // System.out.println(dSnapshot);
        // if (dSnapshot.exists()) {
        // String storedPass = dSnapshot.getString("password");
        // return password.equals(storedPass);
        // }
        // return false;
    }
    public static List<Map<String, Object>> getDataInDescendingOrder(String collectionName,
            String orderByField) throws ExecutionException, InterruptedException {
        List<Map<String, Object>> documentsList = new ArrayList<>();

        // Create a query against the collection
        CollectionReference collection = db.collection(collectionName);
        Query query = collection.orderBy(orderByField,Query.Direction.DESCENDING);

        // Execute the query
        ApiFuture<QuerySnapshot> querySnapshot = query.get();

        for (DocumentSnapshot document : querySnapshot.get().getDocuments()) {
            documentsList.add(document.getData());
        }

        return documentsList;
    }

    private void showAlert(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(message);
            alert.show();
        });
    }
}
