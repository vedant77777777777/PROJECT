package com.example;

public interface slidingMenu {

}
