package com.example;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.firebase_connections.FirebaseServices;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AdminLandingPage  {

    private HomeLogin loginPage;
    private SplashScreen splashScreen;
    private ScrollPane scrollPane;
    private Stage primaryStage;
    private static Scene scene;

    
    public AdminLandingPage(Stage primaryStage){
        this.primaryStage= primaryStage;
        this.scene=initAdminLAndingScene(primaryStage);
    }
    public Scene initAdminLAndingScene(Stage primaryStage){
        // Load logo image
        Image logo = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\logo-no-background.png");
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(140);
        logoView.setPreserveRatio(true);

        // Avatar Profile Section
        Image avatarImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\blue-circle-with-white-user.png");
        ImageView avatarView = new ImageView(avatarImage);
        avatarView.setFitHeight(80);
        avatarView.setPreserveRatio(true);

        // Edit Profile Button
        Button editProfileButton = new Button("Edit Profile");
        editProfileButton.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        editProfileButton.setTextFill(Color.WHITE);
        editProfileButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 20px; -fx-background-radius: 20px;");
        editProfileButton.setOnMouseEntered(e -> editProfileButton.setStyle("-fx-background-color: #222222; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 20px; -fx-background-radius: 20px;"));
        editProfileButton.setOnMouseExited(e -> editProfileButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 20px; -fx-background-radius: 20px;"));
        editProfileButton.setOnAction(e -> {
            // Navigate to EditProfilePage
            EditProfilePage editProfilePage = new EditProfilePage(primaryStage);
           primaryStage.setScene(EditProfilePage.getScene());
            
        });
        // About Button (New button above the Logout button)
       // About Button (New button above the Logout button)
        Button aboutButton = new Button("About");
        aboutButton.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        aboutButton.setTextFill(Color.WHITE);
        aboutButton.setStyle("-fx-background-color: #1e88e5; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 20px; -fx-background-radius: 20px;");
        aboutButton.setOnAction(e -> {
            // Navigate to AboutPage
            AboutPage aboutPage = new AboutPage(primaryStage); // Assuming AboutPage constructor takes primaryStage
            primaryStage.setScene(aboutPage.getScene());
        });
        VBox profileBox = new VBox(5, avatarView, editProfileButton,aboutButton); // Reduced gap from 10 to 5
        profileBox.setAlignment(Pos.CENTER);
        profileBox.setPadding(new Insets(20));

        // Logout Button
        Button logoutButton = new Button("Logout");
        logoutButton.setStyle("-fx-font-size: 15px; -fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 10px 20px;");
        logoutButton.setOnAction(e -> handleLogout(primaryStage));

        // Header
        HBox headerBox = new HBox();
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setBackground(new Background(new BackgroundFill(Color.rgb(128, 128, 128, 0.7), CornerRadii.EMPTY, Insets.EMPTY)));
        headerBox.setPadding(new Insets(15));

        // Set alignment for profile and logout
        HBox profileContainer = new HBox(profileBox);
        profileContainer.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(profileContainer, Priority.ALWAYS);

        HBox logoContainer = new HBox(logoView);
        logoContainer.setAlignment(Pos.CENTER);

        HBox logoutContainer = new HBox(logoutButton);
        logoutContainer.setAlignment(Pos.CENTER_RIGHT);
        HBox.setHgrow(logoutContainer, Priority.ALWAYS);

        headerBox.getChildren().addAll(profileContainer, logoContainer, logoutContainer);

        // Footer
        Text footer = new Text("© 2024 HireBridge. All rights reserved.");
        footer.setFont(Font.font("Arial", FontWeight.NORMAL, 15));
        footer.setFill(Color.WHITE);
        StackPane footerBox = new StackPane(footer);
        footerBox.setAlignment(Pos.CENTER);
        footerBox.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));
        footerBox.setPadding(new Insets(15));

        // Cards with different images and button functionalities
        Image cardImage1 = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\softwereland.jpg");
        Image cardImage2 = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\testerland.jpg ");
        Image cardImage3 = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\Dataanalystland.jpg");
        Image cardImage4 = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\mobileland.jpg");
        Image cardImage5 = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\networkland.jpg");
        Image cardImage6 = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\desingengland.jpg");

        // Create cards for the top row (horizontally aligned)
        new HiringForm(primaryStage);
        VBox vbox= new VBox();
        HBox topRow = new HBox(20,
                createCard(cardImage1, "Select", "Software Developer", e -> {
                    System.out.println(111);
                   
                   
                   primaryStage.setScene(HiringForm.getHiringForm());
                }),
                createCard(cardImage2, "Select", "Tester", e -> {
                  
                    primaryStage.setScene(HiringForm.getHiringForm());
                }),
                createCard(cardImage3, "Select", "Data Analyst", e -> {

                    primaryStage.setScene(HiringForm.getHiringForm());
                })
        );
        topRow.setAlignment(Pos.CENTER);
        topRow.setPadding(new Insets(20));

        // Create cards for the bottom row (aligned below the top row)
        HBox bottomRow = new HBox(20,
                createCard(cardImage4, "Select", "Mobile Developer", e -> {
                    primaryStage.setScene(HiringForm.getHiringForm());
                }),
                createCard(cardImage5, "Select", "Network Administrator", e -> {
                    primaryStage.setScene(HiringForm.getHiringForm());
                }),
                createCard(cardImage6, "Select", "Design Engineer", e -> {
                    primaryStage.setScene(HiringForm.getHiringForm());                })
        );
        bottomRow.setAlignment(Pos.CENTER);
        bottomRow.setPadding(new Insets(20));

        // Combine both rows in a VBox
        VBox allCardsBox = new VBox(50, topRow, bottomRow); // Increased spacing between rows to 50
        allCardsBox.setAlignment(Pos.CENTER);
        allCardsBox.setPadding(new Insets(50, 0, 50, 0)); // Adjust the margin to ensure it's between header and footer

        // StackPane to overlay the cards over the background and other UI elements
        StackPane cardsPane = new StackPane(allCardsBox);

        // Background Image
        Image backgroundImage = new Image("File:C:\\Users\\DELL\\Downloads\\Hello World (8)\\Hello World\\Hello World\\src\\ASSETS\\images\\BACKGROUNDLANDINGPAGE.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setFitWidth(1920);
        backgroundView.setFitHeight(1080);
        backgroundView.setPreserveRatio(true);
        
        // BorderPane layout to organize header and footer
        BorderPane layout = new BorderPane();
        layout.setTop(headerBox);
        layout.setBottom(footerBox);
        layout.setCenter(cardsPane);
        layout.setLeft(vbox); // Add the cardsPane to the center of the layout
      
        // StackPane to stack background, main layout, and cards
        StackPane stackPane = new StackPane(backgroundView, layout);

        // ScrollPane to enable scrolling without affecting background
        scrollPane = new ScrollPane(stackPane);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        
        // Setting up the Scene
        Scene landingScene = new Scene(scrollPane, 1920, 1080);
        // primaryStage.setScene(landingScene);
        // primaryStage.setResizable(false); // Prevent resizing
        // primaryStage.show();
        return landingScene;
    }
    
    // Method to create a card with image, title, and action, including mouse event handlers for zoom effect
    private VBox createCard(Image image, String buttonLabel, String title, EventHandler<ActionEvent> event) {
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(300); // Reduced width of the card
        imageView.setPreserveRatio(true);
        DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(10.0);
        imageView.setEffect(dropShadow);

        Text cardTitle = new Text(title);
        cardTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        cardTitle.setFill(Color.WHITE);

        Button actionButton = new Button(buttonLabel);
        actionButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        actionButton.setTextFill(Color.WHITE);
        actionButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 20px; -fx-background-radius: 20px;");
        actionButton.setOnAction(event);

        VBox cardBox = new VBox(10, imageView, cardTitle, actionButton);
        cardBox.setAlignment(Pos.CENTER);
        cardBox.setPadding(new Insets(20));
        cardBox.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.7), new CornerRadii(10), Insets.EMPTY)));
        cardBox.setMaxWidth(400); // Set a maximum width for the card

        // Add mouse event handlers for zoom effect
        cardBox.setOnMouseEntered(e -> {
            cardBox.setScaleX(1.1);
            cardBox.setScaleY(1.1);
            cardBox.setEffect(new DropShadow(20, Color.BLACK));
        });
        cardBox.setOnMouseExited(e -> {
            cardBox.setScaleX(1.0);
            cardBox.setScaleY(1.0);
            cardBox.setEffect(null);
        });

        return cardBox;
    }

    // Method to handle logout action
    private void handleLogout(Stage primaryStage) {
        // Navigate back to SplashScreen
        splashScreen = new SplashScreen();
        try {
            splashScreen.start(primaryStage);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // Simulate a delay before moving to LoginPage
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        // Navigate to LoginPage after delay
                        loginPage = new HomeLogin();
                        try {
                            loginPage.start(primaryStage);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                },
                2000 // Delay in milliseconds (2 seconds)
        );
    }

    // Method to navigate to HiringForm page
    // private void navigateToHiringForm(Stage primaryStage) {
    //     HiringForm hiringForm = new HiringForm();
    //     try {
    //         hiringForm.start(primaryStage);
    //     } catch (Exception ex) {
    //         ex.printStackTrace();
    //     }
    // }
    public static Scene getScene(){
        return scene;
    }

}